from django.apps import AppConfig


class BoardsConfig(AppConfig):
    name = 'boards'
